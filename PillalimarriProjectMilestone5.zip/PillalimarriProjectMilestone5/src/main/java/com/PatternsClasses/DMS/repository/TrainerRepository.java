package com.PatternsClasses.DMS.repository;

import org.springframework.data.repository.CrudRepository;

import com.PatternsClasses.DMS.Models.Trainer;

public interface TrainerRepository extends CrudRepository<Trainer, Integer> {

}
	