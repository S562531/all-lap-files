package com.mycompany.app;

import java.util.ArrayList;
import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class MyReducer extends Reducer<Text, Text, Text, Text> {

    @Override
    public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
    
       double maxsalary = Double.MIN_VALUE;
       ArrayList<String> maxPersons = new ArrayList<>();
        for(Text value : values) {
            String[] parts = value.toString().split(",");
            String Surname = parts[0];
            double salary = Double.parseDouble(parts[1]);
            if (salary > maxsalary){
                maxsalary = salary;
                maxPersons.clear();
                maxPersons.add(Surname);
            }
            else if (salary == maxsalary){
            maxPersons.add(Surname);
            }
            }
        
        for(String Surname:maxPersons){
        context.write(key, new Text(Surname + "\t" + maxsalary));
    }
}
}
